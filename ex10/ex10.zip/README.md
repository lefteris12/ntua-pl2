# Start the server

```
php -S localhost:8000
```

# Play the game from the client side

```
./client.py 'http://courses.softlab.ntua.gr/pl2/exercises/solveit.php'

./client.py 'http://localhost:8000/server.php'
```
